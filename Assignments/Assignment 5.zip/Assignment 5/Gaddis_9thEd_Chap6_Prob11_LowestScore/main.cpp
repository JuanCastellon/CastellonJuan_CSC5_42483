
/* 
 * File:   main.cpp
 * Author: Juan Castellon
 * Created on April 13, 2018, 11:27 AM
 * Purpose: CPP Template
 */

//System Libraries
#include <iostream> //I/O Library -> cout, endl
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array C

//Function Prototypes
void gtScre();
void clcAvg();
int findLow();
//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    int tests=5;//Amount of inputted tests
    
    //Initial Variables
    cout<<"This program can calculate the average of 5 test scores and drop "
            "the lowest."<<endl;
    
    
    //Map/Process Inputs to Outputs
    
    
    //Display Outputs
    
    
    //Exit Program!
    return 0;
}

